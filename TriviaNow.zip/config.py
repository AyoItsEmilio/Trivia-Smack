"""
config.py
"""

CSRF_ENABLED = True
DEBUG = True
SECRET_KEY = 'development key'
